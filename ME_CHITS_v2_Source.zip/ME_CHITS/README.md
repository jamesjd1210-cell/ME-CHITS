# ME CHITS v2.0

Android WebView app for offline chit collection administration.

## Included
- PIN-based admin login (initial PIN `1234`; change it in Settings)
- Member management
- Daily collection entry
- Printable payment receipts (Android Print → Save as PDF)
- Arrears report
- Monthly collection report
- JSON backup and restore
- GitHub Actions workflow to build a debug APK

## Build APK
Push the contents of this folder to a GitHub repository, then open **Actions → Build ME CHITS APK → Run workflow**. Download the `ME-CHITS-APK` artifact from the completed workflow run.

## Data and security note
This is an offline prototype. Data is stored locally on the device and can be lost if app data is cleared or the app is uninstalled. Export backups regularly. The initial PIN is not a production-grade authentication system. Do not treat this as a regulated chit-fund accounting or payment platform without appropriate legal, security, and accounting review.
