ME CHITS — Version 2.0 (Android WebView app source)

இந்த ZIP-ல் உள்ளவை:
• PIN அடிப்படையிலான Admin Login (முதல் PIN: 1234; Settings-ல் மாற்றவும்)
• உறுப்பினர் சேர்த்தல் / பட்டியல் / நீக்கம்
• Daily Collection — தேதி, மாத எண், தொகை, payment mode, குறிப்பு
• Payment Receipt — Print dialog மூலம் Save as PDF
• Arrears Report — கணக்கிடும் மாதங்களைத் தேர்வு செய்து பாக்கி கணக்கீடு
• Monthly Collection Report — மாத வாரியான வசூல்
• JSON Backup / Restore
• Android APK உருவாக்க GitHub Actions workflow

முக்கியம்:
1. இது offline/local storage app. தரவு இந்த மொபைலில் மட்டுமே இருக்கும்.
2. App data clear அல்லது uninstall செய்தால் தரவு அழியலாம். அடிக்கடி JSON Backup எடுக்கவும்.
3. முதல் PIN 1234. முதல் Login செய்தவுடன் Settings-ல் மாற்றவும்.
4. PDF ரசீது/அறிக்கை: Receipt அல்லது Report-ல் Print தேர்வு செய்து Android Print screen-ல் Save as PDF தேர்வு செய்யவும்.
5. இந்த சூழலில் Android SDK/Gradle நிறுவப்படாததால் இங்கே APK binary உருவாக்கப்படவில்லை. ZIP-ல் APK உருவாக்கத் தேவையான Android project மற்றும் GitHub Actions workflow உள்ளது.

இலவசமாக APK உருவாக்க (மொபைல் வழி):
1. https://github.com திறந்து Sign in / account உருவாக்கவும்.
2. New repository → பெயர் ME-CHITS → Create repository.
3. இந்த ZIP-ஐ unzip செய்து உள்ளே உள்ள கோப்புகள் அனைத்தையும் repository-க்கு upload செய்து Commit செய்யவும்.
4. Actions tab → “Build ME CHITS APK” → Run workflow.
5. Build முடிந்ததும் அந்த workflow run-ல் Artifacts → ME-CHITS-APK ZIP download செய்யவும்.
6. ZIP-ஐ extract செய்து app-debug.apk-ஐ Android-ல் install செய்யவும். கேட்டால் Install unknown apps அனுமதி கொடுக்கவும்.

குறிப்பு: Debug APK தனிப்பட்ட சோதனை/நிறுவலுக்கானது; Play Store வெளியீட்டிற்கான signed release build அல்ல.
உண்மையான சீட்டு/பணப் பரிவர்த்தனைகளுக்கு முன் பொருந்தும் சட்டம், பதிவு, ஒப்பந்தம் மற்றும் கணக்காய்வு தேவைகளை உறுதிசெய்யவும்.
